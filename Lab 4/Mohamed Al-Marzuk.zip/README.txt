Una única observación respecto al código. Tener dentro de la carpeta de "Código fuente" una carpeta con el nombre "notas",
en donde irán las señales de audio. 