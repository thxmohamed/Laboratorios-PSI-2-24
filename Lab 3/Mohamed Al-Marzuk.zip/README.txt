Se pide por consola los índices de 10 señales, de 1 a 169. Mencionar que la entrada esperada son 10 números en ese intervalo separados por espacios, por ejemplo: 3 10 33 35 46 67 72 88 91 106

Las preguntas:
¿Qué dimensiones tienen las matrices del problema? 
¿Cuántas respuestas al impulso de filtros de salida se generan?
¿Cuántas convoluciones son necesarias para obtener la señal de sonido directo?
¿Cómo se utiliza la señal de impulso unitario en el algoritmo MINT?

se responden por consola en Matlab